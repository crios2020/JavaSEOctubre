import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.TreeMap;

public class Clase07 {

	public static void main(String[] args) {
		// Interface Map
		
		Map<String,String>mapSemana;
		
		//Implementación HashMap:	Es la más veloz, no garantiza el orden de los elementos
		//mapSemana=new HashMap();
		
		//Implementación Hashtable: Es similar a HashMap, pero es obsoleta (Lenta). (No se recomienda usarla)
		//mapSemana=new Hashtable();
		
		//Implementación LinkedHashMap: Almacena elementos en una lista enlazada, por orden
		//	de ingreso (de llave).
		//mapSemana=new LinkedHashMap();
		
		//Implementación TreeMap: Almacena elementos en un arbol, por orden natural de llaves
		mapSemana=new TreeMap();
		
		
		//App
		
		//Español
		mapSemana.put("lu","lunes");
		mapSemana.put("lu","Lunes");
		mapSemana.put("ma","Martes");
		mapSemana.put("mi","Miércoles");
		mapSemana.put("ju","Jueves");
		mapSemana.put("vi","Viernes");
		mapSemana.put("sa","Sábado");
		mapSemana.put("do","Domingo");
		
		//Ingles
//		mapSemana.put("lu","Monday");
//		mapSemana.put("ma","Tuesday");
//		mapSemana.put("mi","Wednesday");
//		mapSemana.put("ju","Thursday");
//		mapSemana.put("vi","Fryday");
//		mapSemana.put("sa","Saturday");
//		mapSemana.put("do","Sundat");
		
		
		//mapSemana.put("lu","Java");
		separador();
		System.out.println(mapSemana.get("lu"));
		separador();
		mapSemana.forEach((k,v)->System.out.println(k+" "+v));
		
		List<Auto>lista= new ArrayList();
				
	
		lista.add(new Auto("Ford","Ka","Negro"));
		lista.add(new Auto("Fiat","Idea","Gris"));
		lista.add(new Auto("Citroen","C4","Bordo"));
		lista.add(new Auto("Peugeot","2008","Blanco"));
		lista.add(new Auto("Renault","Kangoo","Verde"));
		lista.add(new Auto("WV","Gol","Blanco"));
		lista.add(new Auto("Fiat","Toro","Negro"));
	
		separador();
		lista.forEach(System.out::println);
		
		
		// Pilas y Colas
		
		//Pilas clase Stack - LIFO - Last In First Out (Ultimo en Entrar Primero en Salir)
		Stack<Auto> pila=new Stack();
		pila.push(new Auto("BMW","170","Negro")); //método .push(): Apila un elemento
		
		pila.addAll(lista);
		
		separador();
		pila.forEach(System.out::println);
		
		separador();
		System.out.println("Longitud de pila: "+pila.size());
		
		while(!pila.isEmpty()) {
			System.out.println(pila.pop());		//método .pop(): Desapila un elemento
		}
		
		System.out.println("Longitud de pila: "+pila.size());
		separador();
		
		//Colas clase ArrayDeque - FIFO - First In First Out (Primero en Entrar Primero en Salir)
		separador();
		ArrayDeque<Auto>cola=new ArrayDeque();
		
		cola.offer(new Auto("Dodge","RAM","Negro"));	//método .offer(): Encola un elemento
		
		cola.addAll(lista);
		
		separador();
		cola.forEach(System.out::println);
		
		separador();
		System.out.println("Longitud de cola: "+cola.size());
		while(!cola.isEmpty()) {
			System.out.println(cola.poll()); 	//método poll(): desencola un elemento
		}
		System.out.println("Longitud de cola: "+cola.size());
		separador();
		
		
		// Api Stream JDK 8
		lista.add(new Auto("BMW","170","Negro"));
		lista.add(new Auto("Dodge","RAM","Negro"));
		
		separador();
		lista.forEach(System.out::println);
		separador();
		
		//select * from autos where color='negro';
		
		for(Auto a:lista) {
			if(a.getColor().equalsIgnoreCase("negro") && a.getMarca().equalsIgnoreCase("ford")) {
				System.out.println(a);
			}
		}
		
		separador();
		//usando api Stream()
		
		lista
			.stream()
			.filter(a->a.getColor().equalsIgnoreCase("negro") && a.getMarca().equalsIgnoreCase("ford"))
			.forEach(System.out::println);
		
		separador();
		lista
			.stream()
			.sorted()
			.forEach(System.out::println);
		
		separador();
		lista
			.stream()
			.sorted(Comparator.reverseOrder())
			.forEach(System.out::println);
		separador();
		lista
			.stream()
			.sorted(Comparator.comparing(Auto::getMarca))
			.forEach(System.out::println);
			
		
	}
	
	private static void separador() {
		System.out.println("*********************************************************");
	}
}
