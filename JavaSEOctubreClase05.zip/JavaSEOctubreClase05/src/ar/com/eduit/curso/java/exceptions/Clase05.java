package ar.com.eduit.curso.java.exceptions;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Clase05 {
	public static void main(String[] args) {
		
		//El programa se detiene con un error
		//System.out.println(10/0);
		//System.out.println("Esta sentencia no se ejecuta!");
		
		
		/*
		 * 	Estructura try - catch - finally
		 * 
		 * 	try{									//Obligatorio
		 * 		- Colocar aquí las sentencias que pueden arrojar una exception.
		 * 		- Estas sentencias tienen más costo de hardware.
		 * 		- Si se ejecutan normalmente (sin errores) las sentencia, el bloque
		 * 			termina la ejecución normalmente, y salta el control del programa
		 * 			al bloque finally.
		 * 		- Si alguna sentencia arroja Exception, el control del programa salta
		 * 			al bloque catch, y no se detiene el programa.
		 * 	} catch(Exception e){					//Obligatorio
		 * 		- Este bloque se ejecuta cuando se arroja una exception.
		 * 		- Se recibe como parametro un objeto de Exception.
		 * 		- El bloque termina y continua el control del programa en el bloque 
		 * 			finally
		 * 		System.out.println(e.toString());
		 * 	} finally {								//Opcional
		 * 		- Este bloque se ejecuta siempre. 
		 * 		- Si no existe este bloque el programa termina normalmente.
		 * 		- Las variables declaradas en bloque try o catch, estan fuera de 
		 * 			alcance.
		 * 	}
		 * 	- El programa termina normalmente.
		 */
		
		try {
			int a=1;
			System.out.println(10/0);
			System.out.println("Esta sentencia no se ejecuta!");
		} catch (Exception e) {
			int b=2;
			//System.out.println(a); //fuera de alcance
			System.out.println("Ocurrio un error!");
			System.out.println(e);			//sincronizado
			//System.err.println(e);			//desincronizado
			//System.out.println(e.getStackTrace());
			//StackTraceElement[] vector=e.getStackTrace();
			//for(int a=0;a<vector.length;a++) System.out.println(vector[a]);
			//e.printStackTrace();
		} finally {
			System.out.println("El programa termina normalmente!");
			//System.out.println(a);
			//System.out.println(b);
		}
		
		System.out.println("**************************************************");
		try {
			//GeneradorExceptions.generar();
			//GeneradorExceptions.generar(true);
			//GeneradorExceptions.generar("338v");
			//GeneradorExceptions.generar(null, 2);
			GeneradorExceptions.generar("hola",23);
		} catch (Exception e) {
			System.out.println(e);
			//e.printStackTrace();
		}
		
		System.out.println("**************************************************");
		//Captura personalizada de exceptions
		
		//GeneradorExceptions.generar("hola",23);			//UncheckedExcepetion
		//FileReader in=new FileReader("texto.txt");		//CheckedException
		
		try {
			//GeneradorExceptions.generar();
			//GeneradorExceptions.generar(true);
			//GeneradorExceptions.generar("338v");
			//GeneradorExceptions.generar(null, 2);
			//GeneradorExceptions.generar("hola",23);
			FileReader in=new FileReader("texto.txt");
		//} catch (ArrayIndexOutOfBoundsException e) 	{ System.out.println("Indice Fuera de Rango!");
		} catch (ArithmeticException e) 			{ System.out.println("División / 0");
		} catch (NumberFormatException e) 			{ System.out.println("Formato de número incorrecto!");
		} catch (NullPointerException e) 			{ System.out.println("Puntero Nulo!");
		//} catch (StringIndexOutOfBoundsException e) { System.out.println("Indice Fuera de Rango!");
		//Multicatch
		//} catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) { System.out.println("Indice Fuera de Rango!");
		} catch (IndexOutOfBoundsException e)		{ System.out.println("Indice Fuera de Rango!");
		} catch (FileNotFoundException e)			{ System.out.println("Archivo no encontrado!");
		} catch (IOException e) 					{ System.out.println("Error IO!");
		} catch (Exception e) 						{ System.out.println("Ocurrio un error no esperado!");
		}
		
		System.out.println("**************************************************");

		//No hacer esto!!!!!!
//		FileReader in=null;
//		try {
//			in=new FileReader("texto.txt");
//			System.out.println(in.read());
//		} catch (Exception e) {
//			System.out.println(e);
//		} finally {
//			if(in!=null) {
//				try{
//					in.close();
//				}catch(Exception e) {
//					System.out.println(e);
//				}
//			}
//		}
		
		//try with resources JDK 7
		try (FileReader in=new FileReader("texto.txt")){
			System.out.println(in.read());
		} catch (Exception e) {
			System.out.println(e);
		}
		
		System.out.println("**************************************************");
		//Uso de Exceptions para manejar reglas de negocio
		
		Vuelo v1=new Vuelo("aer1234",100);
		Vuelo v2=new Vuelo("lat1111",100);
		
//		try {
//			v1.venderPasajes(50);
//			v2.venderPasajes(20);
//			v1.venderPasajes(30);
//			v2.venderPasajes(20);
//			v1.venderPasajes(30); 					//Lanza una Exception
//			v2.venderPasajes(10); 					//Esta venta no se ejecuta
//		}catch (NoHayMasPasajesException e) {
//			System.out.println(e);
//		}
		
		try {
			v1.venderPasajes(50);
		} catch (NoHayMasPasajesException e) {
			System.out.println(e);
		}
		
		try {
			v2.venderPasajes(20);
		} catch (NoHayMasPasajesException e) {
			System.out.println(e);
		}
		
		try {
			v1.venderPasajes(30);
		} catch (NoHayMasPasajesException e) {
			System.out.println(e);
		}
		
		try {
			v2.venderPasajes(20);
		} catch (NoHayMasPasajesException e) {
			System.out.println(e);
		}
	}
}
