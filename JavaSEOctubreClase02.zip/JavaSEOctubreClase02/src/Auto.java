
//Declaración de clases
public class Auto {
	
	//Atributos
	String marca;
	String modelo;
	String color;
	int velocidad;
	
	//Métodos constructores
	
	/**
	 * Método deprecado por Carlos Rios el 12/10/2021 por ser inseguro
	 * Usar en su reemplazo Auto(String marca, String modelo) o 
	 * Auto(String marca, String modelo, String color)
	 */
	@Deprecated
	Auto(){}	//Constructor vacio
	
	Auto(String marca, String modelo, String color){
		this.marca=marca;
		this.modelo=modelo;
		this.color=color;
	}
	
	Auto(String marca, String modelo){
		this.marca=marca;
		this.modelo=modelo;
		this.color="Rojo";	//color por default
	}
	
	//Métodos
	void acelerar() {											//acelerar
		//velocidad+=10;
		//if(velocidad>100) velocidad=100;
		acelerar(10);	//llamado a método de la misma clase
	}
	
	//método sobrecargado
	//método con parámetro de entrada
	void acelerar(int kilometros) {								//acelerarInt
		velocidad+=kilometros;
		if(velocidad>100) velocidad=100;
	}
	
	//void acelerar(int x) {}										//acelerarInt	Error
	
	void acelerar(int x, int y) {}								//acelerarIntInt
	
	void acelerar(int x, String y) {}							//acelerarIntString
	
	void acelerar(String x) {}									//acelerarString
	
	void frenar() {
		velocidad-=10;
	}
	
	void imprimirVelocidad() {
		System.out.println(velocidad);
	}
	
	int obtenerVelocidad() {
		return velocidad;
	}
	
	@Override
	public String toString() {
		return marca+" "+modelo+" "+color+" "+velocidad;
	}

}//end class
