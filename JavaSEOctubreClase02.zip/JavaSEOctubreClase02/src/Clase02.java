import javax.swing.JOptionPane;

public class Clase02 {
	public static final String ANSI_BLACK = "\u001B[30m";
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_BLUE = "\u001B[34m";
	public static final String ANSI_PURPLE = "\u001B[35m";
	public static final String ANSI_CYAN = "\u001B[36m";
	public static final String ANSI_WHITE = "\u001B[37m";
	public static final String ANSI_RESET = "\u001B[0m";
	
	public static void main(String[] args) {
		// Clase 02 - Programación Orientada a Objetos.
		
		/*
		 * Que es una Clase?
		 * 	Una clase se detecta como sustantivo y forma una plantilla que 
		 * 	permite generar nuevos Objetos.
		 * 
		 * Clases en Java?
		 * 	Las clases son objetos de la clase java.lang.Class
		 * 
		 * Que es un atributo?
		 * 	Los atributos describen a la clase, son variables contenidas dentro
		 * 	de la clase, (Se detectan como adjetivos), tienen un tipo de datos
		 * 	asignado y un proceso de validación.
		 * 
		 * Atributos en Java?
		 * 	Los atributos son objetos de la clase java.lang.reflect.Field
		 * 
		 * Que es un método?
		 * 	Un método es una acción que realiza la clase. Se detecta como verbo.
		 * 	Pueden existir parametros de entrada y salida.
		 * 
		 * Métodos en Java?
		 * 	Los métodos son objetos de la clase java.lang.reflect.Field
		 * 
		 * Argumentos(Parámetros) de entrada a un método:
		 * 	Son valores enviados al método, el método usa estos valores para hacer un
		 * 	pocesamiento, los parámetros tienen un tipo de datos asociado. 
		 * 
		 * Sobrecarga de Métodos:
		 * 	Es la presencia de métodos con el mismo nombre dentro de una clase, pero con dinstinta
		 * 	firma de parametros de entrada.
		 * 
		 * Retorno de valor en método o valor de salida:
		 * 	El método puede devilver un valor de salida al terminar la ejecución.
		 * 	El valor retornado tiene un tipo de datos asociado.
		 * 
		 * Métodos Constructores:
		 * 	Son métodos que inicializan un objeto, Se invocan al construir un objeto con la 
		 * 	palabra new, tienen parámetros de entrada, no tiene valor de salida, pueden
		 * 	sobrecargarse, tienen el mismo nombre que la clase.
		 * 	Cuando una clase no tiene constructor se agrega uno vacio al compilar.
		 * 
		 * Constructores en Java:
		 * 	Son Objetos de la clase java.lang.reflect.Constructor
		 * 
		 * Que son los Objetos?
		 * 	Los objetos son son instancia de la clase y representa una 
		 * 	situación en particular. Las clases declaran atributos y 
		 * 	en los objetos se completa el valor de los atributos (Estado).
		 * 	Los atributos tiene un proceso de inicialización automatico.
		 * 
		 */

		System.out.println(ANSI_GREEN+"-- auto1 --"+ANSI_RESET);
		Auto auto1=new Auto();		// se construye un objeto del tipo Auto
		
		//colocar estado al objeto auto1
		auto1.marca = "Fiat";
		auto1.modelo = "Toro";
		auto1.color = "Negro";
		
		//usar sus métodos (operaciones - servicios)
		auto1.acelerar();		//10		
		auto1.acelerar();		//20
		auto1.acelerar();		//30
		auto1.frenar();			//20
		auto1.acelerar(16); 	//36

		
		System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);
		
		System.out.println(ANSI_GREEN+"-- auto2 --"+ANSI_RESET);
		Auto auto2=new Auto();
		auto2.marca="Ford";
		auto2.modelo="Ka";
		auto2.color="Negro";
		
		for(int a=0;a<=53;a++) auto2.acelerar();
		
		System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);
		
		auto2.imprimirVelocidad();
		System.out.println(auto2.obtenerVelocidad());
		
		//JOptionPane.showMessageDialog(null, "Velocidad: "+auto2.obtenerVelocidad());
		
		System.out.println("-- auto3 --");
		Auto auto3=new Auto("Dodge","Caravan","Rojo");
		auto3.acelerar(38);
		
		//método .toString()
		System.out.println(auto3.toString());
		System.out.println(auto3);
		
		String texto;
		int numero;
		//System.out.println(texto+" "+numero);
		//Error variable no inicializada
		
		//Eclipse:	syso - ctrol - space
		//Netbeans:	sout - tab
		
		System.out.println("-- empleado1 --");
		Empleado empleado1=new Empleado(1,"Ana","Molina",EstadoCivil.CASADO,300000);
		//empleado1.sueldoBasico=8000000;
		empleado1.setSueldoBasico(8000000);
		
		System.out.println(empleado1.toString());
		
		
		
		//String[] semana= {"Lunes","Martes","Miercoles","Jueves","Viernes"};
		//metodo1(semana);
		//metodo2(semana);
		//metodo2("primavera","verano","otoño","invierno");
		
		//System.out.println("**************************************************************");
		//metodo2(args);
		
		
		/*
		 * 
		 * Pendiente modificadores de visibilidad
		 * 
		 */

	}
	
	public static void metodo1(String[] args) {
		for(int a=0;a<args.length;a++) System.out.println(args[a]);
	}

	public static void metodo2(String... args) { //varargs jdk5
		for(int a=0;a<args.length;a++) System.out.println(args[a]);
	}
}
