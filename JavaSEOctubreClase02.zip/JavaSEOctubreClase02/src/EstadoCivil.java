
public enum EstadoCivil {
	SOLTERO,
	CASADO,
	VIUDO,
	DIVORCIADO
}
