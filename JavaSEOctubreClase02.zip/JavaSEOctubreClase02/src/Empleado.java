
public class Empleado {
	private int nro;
	private String nombre;
	private String apellido;
	private EstadoCivil estadoCivil;
	private double sueldoBasico;
	public Empleado(int nro, String nombre, String apellido, EstadoCivil estadoCivil, double sueldoBasico) {
		this.nro = nro;
		this.nombre = nombre;
		this.apellido = apellido;
		this.estadoCivil = estadoCivil;
		this.sueldoBasico = sueldoBasico;
	}
	@Override
	public String toString() {
		return "Empleado [nro=" + nro + ", nombre=" + nombre + ", apellido=" + apellido + ", estadoCivil=" + estadoCivil
				+ ", sueldoBasico=" + sueldoBasico + "]";
	}
	public int getNro() {
		return nro;
	}
	public void setNro(int nro) {
		this.nro = nro;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public EstadoCivil getEstadoCivil() {
		return estadoCivil;
	}
	public void setEstadoCivil(EstadoCivil estadoCivil) {
		this.estadoCivil = estadoCivil;
	}
	public double getSueldoBasico() {
		return sueldoBasico;
	}
	public void setSueldoBasico(double sueldoBasico) {
		this.sueldoBasico = sueldoBasico;
	}
}
