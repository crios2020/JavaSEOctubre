package ar.com.eduit.curso.java.interfaces;

public interface I_File {

	/*
	 * interfaces:
	 * 			- No tiene atributos, ni constructores
	 * 			- Solo tienen métodos abstractos o atributos constantes
	 * 			- Todos sus miembros son publico.
	 * 			- Las clases que implementan la interface deben implementar
	 * 				los métodos abstractos.
	 * 			- Una clase puede implementar muchas interfaces.
	 */
	
	/**
	 * La java doc es heredada
	 * Este método escribe el archivo
	 * @param text texto a escribir
	 */
	void setText(String text);
	/**
	 * Lee el archivo
	 * @return texto del archivo
	 */
	String getText();
	
	//Interfaces java8 - métodos default
	default void info() {
		System.out.println("Interface I_File");
	}
	
}
