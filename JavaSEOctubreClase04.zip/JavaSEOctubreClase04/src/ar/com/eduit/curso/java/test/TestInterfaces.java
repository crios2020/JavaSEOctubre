package ar.com.eduit.curso.java.test;

import java.util.Scanner;

import ar.com.eduit.curso.java.interfaces.FileBinary;
import ar.com.eduit.curso.java.interfaces.FileCloud;
import ar.com.eduit.curso.java.interfaces.FileText;
import ar.com.eduit.curso.java.interfaces.I_File;

public class TestInterfaces {
	public static void main(String[] args) throws Exception{
		I_File file=null;
		
		//Inicialización
		file=new FileText();
		//file=new FileCloud();
		//file=new FileBinary();
		
		//System.out.println("Ingrese 'FileText' - 'FileCloud' - 'FileBinary':");
		//String input=new Scanner(System.in).nextLine();
		
		//if(input.equals("FileText")) 	file=new FileText();
		//if(input.equals("FileCloud"))	file=new FileCloud();
		//if(input.equals("FileBinary"))	file=new FileBinary();
		
		//deprecado en JDK9
		//file=(I_File)Class.forName("ar.com.eduit.curso.java.interfaces."+input).newInstance();
		//file=(I_File)Class
		//		.forName("ar.com.eduit.curso.java.interfaces."+input)
		//		.getConstructor()
		//		.newInstance();
		
		//app
		file.setText("Hola a todos!");
		System.out.println(file.getText());
		file.info();
		
		
		
	}
}
