package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Persona;
import ar.com.eduit.curso.java.entities.Vendedor;
import ar.com.eduit.curso.java.enums.Moneda;

public class TestHerencia {

	public static void main(String[] args) {
		// Test Herencia
		
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1 = new Cuenta(1, Moneda.ARGS);
		cuenta1.depositar(55000);
		cuenta1.depositar(80000);
		cuenta1.debitar(24000);
		System.out.println(cuenta1.toString());
		
		System.out.println("-- direccion1 --");
		Direccion direccion1=new Direccion("Monroe",3839,"3","a");
		System.out.println(direccion1);
		
		System.out.println("-- direccion2 --");
		Direccion direccion2=new Direccion("Belgrano",45,null,null,"Morón");
		System.out.println(direccion2);
		
		/*
		System.out.println("-- persona1 --");
		Persona persona1=new Persona("Laura",25,direccion1);
		persona1.saludar();
		System.out.println(persona1.toString());
		
		System.out.println("-- persona2 --");
		Persona persona2=new Persona("Ivan",25,persona1.getDireccion());
		persona2.saludar();
		System.out.println(persona2);
		
		System.out.println("-- persona3 --");
		Persona persona3=new Persona("Andrea",24,new Direccion("Lima",222,"1","a"));
		persona3.saludar();
		System.out.println(persona3);
		*/
		
		System.out.println("-- vendedor1 --");
		Vendedor vendedor1=new Vendedor("Miguel",23,direccion2,1,240000);
		vendedor1.saludar();
		System.out.println(vendedor1);
		
		System.out.println("-- cliente1 --");
		Cliente cliente1=new Cliente("Juan",39,direccion1,1,cuenta1);
		cliente1.saludar();
		System.out.println(cliente1);
		
		// Polimorfismo - Poliformismo
		Persona p1=new Vendedor("Javier",36,direccion2,2,500000);
		Persona p2=new Cliente("Gabriela",28,direccion1,2,new Cuenta(11,Moneda.ARGS));
		
		p1.saludar();
		p2.saludar();
		
		Vendedor v1;
		//v1=(Vendedor)p1;
		
		v1=(p1 instanceof Vendedor)?(Vendedor)p1:null;
		
		Object obj=v1;
		obj=2;
		obj="String";
		
		System.out.println(p1.getClass());
		System.out.println(p1.getClass().getName());
		System.out.println(p1.getClass().getSimpleName());
		System.out.println(p1.getClass().getSuperclass().getName());
		System.out.println(p1.getClass().getSuperclass().getSuperclass().getName());
		System.out.println(
				p1
				.getClass()
				.getSuperclass()
				.getSuperclass()
				.getSuperclass()
				);
		System.out.println(obj.getClass().getName());
		System.out.println(obj.getClass().getSuperclass().getName());
		
		// interfaces
		
		// static
		
	}

}
