package ar.com.eduit.curso.java.interfaces;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class FileText implements I_File {
	private File file=new File("texto.txt");
	@Override
	public void setText(String text) {
		try (FileWriter out=new FileWriter(file)){
			out.write(text);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public String getText() {
		String text="";
		int car;
		try (FileReader in=new FileReader(file)){
			while((car=in.read())!=-1) {
				text+=(char)car;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return text;
	}

}
