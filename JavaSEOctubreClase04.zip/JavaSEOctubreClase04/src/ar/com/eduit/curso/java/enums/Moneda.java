package ar.com.eduit.curso.java.enums;

public enum Moneda {
	ARGS,
	USD,
	REALES,
	EUROS
}
