package ar.com.eduit.curso.java.entities;

import ar.com.eduit.curso.java.enums.Moneda;

public final class Cuenta {
	private int numero;
	private Moneda moneda;
	private double saldo;
	
	public Cuenta(int numero, Moneda moneda) {
		this.numero = numero;
		this.moneda = moneda;
	}

	public void depositar(double monto) {
		saldo+=monto;
	}
	
	public void debitar(double monto) {
		if(monto<=saldo) {
			saldo-=monto;
		}else {
			System.out.println("Saldo Insuficiente!!");
		}
	}
	
	@Override
	public String toString() {
		return "Cuenta [numero=" + numero + ", moneda=" + moneda + ", saldo=" + saldo + "]";
	}

	public int getNumero() {
		return numero;
	}

	public Moneda getMoneda() {
		return moneda;
	}

	public double getSaldo() {
		return saldo;
	}

}
