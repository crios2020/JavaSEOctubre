package ar.com.eduit.curso.java.entities;

import ar.com.eduit.curso.java.enums.Moneda;

public class ClientePersona {
	private int nro;
	private String nombre;
	private int edad;
	private Cuenta cuenta;

	
	/*
	 * Un cliente puede ser creado sin una cuenta.
	 */
//	public ClientePersona(int nro, String nombre, int edad) {
//		this.nro = nro;
//		this.nombre = nombre;
//		this.edad = edad;
//	}
	
	/*
	 * Un cliente se crea con cuenta obligatoriamente, Una cuenta
	 * puede ser usada por más de un cliente.
	 */
	public ClientePersona(int nro, String nombre, int edad, Cuenta cuenta) {
		this.nro = nro;
		this.nombre = nombre;
		this.edad = edad;
		this.cuenta = cuenta;
	}
	
	/*
	 * Un cliente se crea con cuenta obligatoriamente, Esa cuenta es propia.
	 */
	public ClientePersona(int nro, String nombre, int edad, int numeroCuenta) {
		this.nro = nro;
		this.nombre = nombre;
		this.edad = edad;
		this.cuenta = new Cuenta(numeroCuenta,Moneda.ARGS);
	}

	public void comprar() {
		System.out.println("Comprando algo!");
	}
	
	@Override
	public String toString() {
		return "ClientePersona [nro=" + nro + ", nombre=" + nombre + ", edad=" + edad + ", cuenta=" + cuenta + "]";
	}

	public int getNro() {
		return nro;
	}

	public String getNombre() {
		return nombre;
	}

	public int getEdad() {
		return edad;
	}

	public Cuenta getCuenta() {
		return cuenta;
	}
	
}
