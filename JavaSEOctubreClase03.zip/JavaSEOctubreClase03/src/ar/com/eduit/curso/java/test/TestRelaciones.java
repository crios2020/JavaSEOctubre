package ar.com.eduit.curso.java.test;

import java.util.ArrayList;

import ar.com.eduit.curso.java.entities.ClienteEmpresa;
import ar.com.eduit.curso.java.entities.ClientePersona;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.enums.Moneda;

public class TestRelaciones {

	public static void main(String[] args) {
		// Test Diagrama de Relaciones
		System.out.println("Test Relaciones");

		//Objetos MOCKs (Objetos Simulados)
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1 = new Cuenta(1, Moneda.ARGS);
		cuenta1.depositar(55000);
		cuenta1.depositar(80000);
		cuenta1.debitar(24000);
		System.out.println(cuenta1.toString());
		
		System.out.println("-- clientePersona1 --");
		ClientePersona clientePersona1=new ClientePersona(1,"Josefina",39,cuenta1);
		clientePersona1.getCuenta().depositar(20000);
		System.out.println(clientePersona1);
		
		System.out.println("-- clientePersona2 --");
		ClientePersona clientePersona2=new ClientePersona(2,"Ramiro",38,new Cuenta(2,Moneda.ARGS));
		clientePersona2.getCuenta().depositar(10000);
		
		Cuenta cuentaCliente=clientePersona2.getCuenta();
		cuentaCliente.depositar(10000);
		
		System.out.println(clientePersona2);
		
		System.out.println("-- ana -- juan --");
		ClientePersona ana=new ClientePersona(3,"ana",26,new Cuenta(3,Moneda.ARGS));
		ClientePersona juan=new ClientePersona(4,"juan",29,ana.getCuenta());
		ana.getCuenta().depositar(50000);
		ana.getCuenta().depositar(50000);
		juan.getCuenta().debitar(20000);
		System.out.println(ana);
		System.out.println(juan);
		
		ClientePersona clientePersona5=new ClientePersona(5,"Diego",23,5);
		clientePersona5.getCuenta().depositar(36000);
		System.out.println(clientePersona5);
		
		ClientePersona clientePersona6=new ClientePersona(6,"Debora",23,5);
		clientePersona6.getCuenta().depositar(6000);
		System.out.println(clientePersona6);
		
		System.out.println("-- clienteEmpresa1 --");
		ClienteEmpresa clienteEmpresa1=new ClienteEmpresa(1,"Cafe Sebolla","Lima 444");
		ArrayList<Cuenta> cuentas=clienteEmpresa1.getCuentas();
		cuentas.add(new Cuenta(10,Moneda.ARGS));		// 0
		cuentas.add(new Cuenta(11,Moneda.REALES));		// 1
		cuentas.add(new Cuenta(12,Moneda.USD));			// 2
		cuentas.get(0).depositar(400000);
		cuentas.get(0).depositar(25000);
		cuentas.get(0).debitar(2000);
		cuentas.get(1).depositar(50000);
		cuentas.get(2).depositar(14000);
		System.out.println(clienteEmpresa1);
		
		
	}

}
