package ar.com.eduit.curso.java.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {
	private static final String driver="org.mariadb.jdbc.Driver";
	private static final String url="jdbc:mariadb://localhost:3306/colegio?serverTimezone=UTC";
	private static final String user="root";
	private static final String pass="";
	private Connector() {}
	public static Connection getConnection() {
		try {
			Class.forName(driver);	//registramos el Driver
			return DriverManager.getConnection(url,user,pass);
		}catch(Exception e) {
			System.out.println(e);
			return null;
		}
	}
}
