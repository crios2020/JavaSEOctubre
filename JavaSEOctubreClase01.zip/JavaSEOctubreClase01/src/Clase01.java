import java.time.LocalDate;

import javax.swing.JOptionPane;



/**
 * Clase principal de proyecto
 * @author carlos
 *
 */
public class Clase01 {

	/**
	 * punto de entrada del proyecto
	 * @param args argumentos que ingresan desde consola
	 */
	public static void main(String[] args) {
		/*
		 	Curso: 	Java Standard Web Programming		40 hs.
		 	Días:	Lunes Martes Miércoles	10:00 a 13:00 hs.
		 	Profe: 	Carlos Rios		carlos.rios@educacionit.com
		 	
		 	Materiales:		alumni.educacionit.com
		 					user: email
		 					pass: dni
		 					alumnos@educacionit.com
		 					
		 	Github:	https://github.com/crios2020/JavaSEOctubre
		 	
		 	Software: JDK 11 LTS o sup	- Eclipse for java EE & web develop
		 					
		 	https://www.oracle.com/java/technologies/javase/jdk17-archive-downloads.html
		 	
		*/
		
		String texto="Hola";
		
		System.out.println("Hola Mundo!");
		
		// syso - ctrol - space : atajo para System.out.println();
		
		// Linea de comentarios!!
		
		/* Bloque de comentarios */
		
		/**
		 * Comentario javaDoc:
		 * 	- Puede verse desde fuera del binario.
		 * 	- Debe colocarse delante de la declaración de método, o delate de la declaración de clase
		 */
		
		Clase01.fecha();
		
		// Java C# C++: son lenguajes de tipado fuerte
		// PHP Python javascript: son lenguajes de tipado debil
		
		//Tipo de datos primitivos
		
		//Tipo de datos enteros
		
		//Tipo de datos boolean				1 byte
		boolean bo=true;
		System.out.println(bo);
		bo=false;
		System.out.println(bo);
		
		//Tipo de datos byte				1 byte			-128 127
		byte by=-100;
		System.out.println(by);
		
		//Tipo de datos short				2 bytes
		short sh=20000;
		System.out.println(sh);
		
		//Tipo de datos int					4 bytes
		int in=2000000000;
		System.out.println(in);
		
		//Tipo de datos long				8 bytes
		long lo=3000000000L;
		System.out.println(lo);
		
		//Tipo de datos char				2 bytes
		char ch=65;
		System.out.println(ch);
		ch='h';
		System.out.println(ch);
		
		//Tipo de punto flotante
		
		//Tipo de datos float 32 bits
		float fl=4.25123456789f;
		System.out.println(fl);
		
		//Tipo de datos double 64 bits
		double dl=4.25123456789;
		System.out.println(dl);
		
		//Clase String
		String st="Hola";
		System.out.println(st);
		
		texto="Esto es una cadena de texto!";
		System.out.println(texto);
		//System.out.println(texto.value);
		
		//recorrido de texto
		for(int a=0;a<texto.length();a++) {
			System.out.print(texto.charAt(a));
		}
		System.out.println();
		
		//imprimir vector en mayusculas
		for(int a=0;a<texto.length();a++) {
			char car=texto.charAt(a);
			if(car>=97 && car<=122) car-=32;
			System.out.print(car);
		}
		System.out.println();
		
		//Operador Ternario ?
		for(int a=0;a<texto.length();a++) {
			char car=texto.charAt(a);
			System.out.print((car>=97 && car<=122)?car-=32:car);
		}
		System.out.println();
		
		//imprimir vector en minusculas
		for(int a=0;a<texto.length();a++) {
			char car=texto.charAt(a);
			System.out.print((car>=65 && car<=90)?car+=32:car);
		}
		System.out.println();
		
		System.out.println(texto.toLowerCase());
		System.out.println(texto.toUpperCase());
		
		//JOptionPane.showMessageDialog(null, "Hola a todos!");
		
		//Tipo de datos var		JDK 9 o sup.
		var var1=5;				//int
		var1=20;
		//var1=3.45;				//error
		var var2=true;			//boolean
		var var3="H";			//String
		var var4='H';			//char
		var var5=3.55;			//double
		var var6=3.55d;			//double
		var var7=3.55f;			//float
		var var8=2L;			//long
		
		metodo(2.5f);
	}
	
	public static void metodo (double x) {
		System.out.println("double");
	}
	
	public static void metodo (float x) {
		System.out.println("float");
	}
	
	/**
	 * Este método imprime la fecha actual
	 */
	public static void fecha() {
		System.out.println(LocalDate.now());
	}
	
	
	

}
